<?php return
  array (
    'trans' => 
    array (
      'Main Interface' => 
      array (
        'Date Format: Files' => 'm/d/Y h:i A',
      ),
      'Versioning' => 
      array (
        'Date Format: Grid - Date' => 'm/d/Y h:i A',
      ),
      'Admin: Users' => 
      array (
        'Date Format: Registration date' => 'd M Y',
        'Date Format: Last login' => 'd M Y, H:i',
        'Date Format: Expiration date' => 'd M Y',
      ),
      'Admin: Logs' => 
      array (
        'Date Format: Grid - Date' => 'm/d/Y h:i A',
      ),
    ),
);